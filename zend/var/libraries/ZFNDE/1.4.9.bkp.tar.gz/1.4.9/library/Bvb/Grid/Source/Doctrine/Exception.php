<?php

class Bvb_Grid_Source_Doctrine_Exception extends Exception
{
    
}