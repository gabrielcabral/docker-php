<?php
class Fnde_Business_Perfil {
	
   public function verificaOrcamento($arParams = null)
   {
       echo "passou pelo negocio";
   } 
}