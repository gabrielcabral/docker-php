<?php
abstract class Fnde_Model_Service_Abstract extends Zend_Db_Table 
{
	
}