<?php
class Fnde_Message {
	const MSG_SUCCESS = 'msgSucesso';
	const MSG_ALERT   = 'msgAlerta';
	const MSG_ERROR   = 'msgErro';
    const MSG_INFO    = 'msgOrientacao';
}