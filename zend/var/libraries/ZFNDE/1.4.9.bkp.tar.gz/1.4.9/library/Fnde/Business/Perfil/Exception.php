<?php
class Fnde_Business_Perfil_Exception extends Fnde_Business_Exception 
{
}